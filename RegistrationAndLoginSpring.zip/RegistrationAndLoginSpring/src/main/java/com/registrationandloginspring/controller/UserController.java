package com.registrationandloginspring.controller;

import com.registrationandloginspring.model.dto.LoginRequest;
import com.registrationandloginspring.model.dto.RegistrationRequest;
import com.registrationandloginspring.model.dto.UserResponse;
import com.registrationandloginspring.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

  private final UserService userService;

  public UserController(UserService userService) {
    this.userService = userService;
  }

  @ResponseStatus(HttpStatus.CREATED)
  @PostMapping("/user/register")
  public UserResponse registerUser(@Valid @RequestBody RegistrationRequest registrationRequest) {
    return userService.register(registrationRequest);
  }

  @PostMapping("/user/login")
  public Long login(@Valid @RequestBody LoginRequest loginRequest) {
    return userService.login(loginRequest);
  }
}
